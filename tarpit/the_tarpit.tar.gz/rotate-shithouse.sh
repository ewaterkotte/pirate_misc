i=1
while [[ "$i" -gt 0 ]] ; do 
	let relink=$((RANDOM%11))
	echo cp -f /tmp/shithouse/tarpit"$relink".html /tmp/shithouse/index.html
	sleep 30 
done
