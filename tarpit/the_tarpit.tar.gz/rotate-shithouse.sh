#!/bin/bash
i=1
while [[ "$i" -gt 0 ]] ; do 
	let relink=$((RANDOM%16))
	sleep 63
	echo cp -f /tmp/shithouse/tarpit"$relink".html /tmp/shithouse/index.html 
done
