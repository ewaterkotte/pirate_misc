#!/bin/bash
iptables -t nat -I PREROUTING 1 -i eth0 -p tcp -m tcp -m state --state NEW --dport 0:65535 -j DNAT --to-destintion <webserver>(192.168.10.10:81)
