#!/bin/bash

ap_backup = ap.backups
a2_conf_dir = /etc/apache2
 
mkdir $ap_backup 

echo "NameVirtualHost *:81" >> header.txt
echo "Listen 81" >> header.txt
cat header.txt $a2_conf_dir/ports.conf >> newports.conf

mv shithouse /tmp/
mv $a2_conf_dir/ports.conf $ap_backup/
mv newports.conf $a2_conf_dir/ports.conf
mv pencol_tarpit $a2_conf_dir/sites-avialable/
a2ensite pencol_tarpit

service apache2 stop
sleep 2
service apache2 start

nohup ./rotate-shithouse.sh &
 
