#!/bin/bash
infinite=1
while [[ "$infinite" -gt 0 ]] ; do 
	let relink=$((RANDOM%16))
	newpage=tarpit"$relink".html
	sleep 123
	if [[ -r /tmp/shithouse/$newpage ]] ; then
		cp -f /tmp/shithouse/$newpage /tmp/shithouse/index.html
	fi 
done
