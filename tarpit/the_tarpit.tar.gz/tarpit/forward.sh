#!/bin/bash
iptables -t nat -I PREROUTING 1 -i eth0 -p tcp -m tcp -m state --state NEW --dport 0:65535 -j DNAT --to-destination <webserver>(192.168.10.10:81)
# if $has_fw
iptables -A INPUT -i eth0 -p tcp -m tcp -m state --state NEW --dport 81 -j ACCEPT
